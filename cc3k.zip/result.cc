#include "result.h"

result::result(std::string s): consequence{s} {}

result::~result(){}
