#ifndef __RESULT__
#define __RESULT__

#include<string>

class result{
     public:
     std::string consequence;
     result(std::string s);
     ~result();
};
#endif
