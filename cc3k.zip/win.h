#include<string>
class result{
     public:
     std::string consequence;
}
