#ifndef _POSN_H_
#define _POSN_H_

class Posn
{
  int x, y;
  public: 
  Posn(int x, int y);
  int getX();
  int getY();
};

#endif
