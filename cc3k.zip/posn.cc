#include "posn.h"

int Posn::getX() { return x; }
int Posn::getY() { return y; }
Posn::Posn(int x, int y): x{x}, y{y}{}
